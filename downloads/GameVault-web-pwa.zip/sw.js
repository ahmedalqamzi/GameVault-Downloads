const CACHE = "gamevault-shell-v12";

function scoped(path) {
  return new URL(path, self.registration.scope).toString();
}

async function precacheShell() {
  const cache = await caches.open(CACHE);
  const indexURL = scoped("./index.html");
  const response = await fetch(new Request(indexURL, { cache: "reload" }));
  if (!response.ok) throw new Error(`Could not cache GameVault (${response.status})`);

  const html = await response.clone().text();
  const assetURLs = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)]
    .map((match) => new URL(match[1], indexURL))
    .filter((url) => url.origin === self.location.origin)
    .map((url) => url.toString());

  await cache.put(scoped("./"), response.clone());
  await cache.put(indexURL, response);
  await cache.addAll([...new Set([
    scoped("./manifest.webmanifest"),
    scoped("./icon.svg"),
    scoped("./icon-180.png"),
    scoped("./icon-1024.png"),
    ...assetURLs,
  ])]);
}

self.addEventListener("install", (event) => {
  event.waitUntil(precacheShell());
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)))),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;

  if (event.request.mode === "navigate") {
    event.respondWith(fetch(new Request(event.request, { cache: "reload" }))
      .then(async (response) => {
        if (response.ok) {
          const cache = await caches.open(CACHE);
          await cache.put(scoped("./"), response.clone());
          await cache.put(scoped("./index.html"), response.clone());
        }
        return response;
      })
      .catch(async () => (
        await caches.match(scoped("./"), { ignoreVary: true })
        || await caches.match(scoped("./index.html"), { ignoreVary: true })
        || Response.error()
      )));
    return;
  }

  event.respondWith(caches.match(event.request, { ignoreVary: true }).then((cached) => {
    const refreshed = fetch(event.request).then(async (response) => {
      if (response.ok) {
        const cache = await caches.open(CACHE);
        await cache.put(event.request, response.clone());
      }
      return response;
    }).catch(() => cached || Response.error());
    return cached || refreshed;
  }));
});
